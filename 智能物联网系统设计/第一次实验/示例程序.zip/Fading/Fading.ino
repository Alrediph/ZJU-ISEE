#define RED   16 //定义LED灯的引脚
#define GREEN 17
#define BLUE  18

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);                  //串口初始化
  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);

}

void loop() {
  // put your main code here, to run repeatedly:
  // fade in from min to max in increments of 5 points:
  for (int fadeValue = 0; fadeValue <= 255; fadeValue += 5) {
    // sets the value (range from 0 to 255):
    analogWrite(RED, fadeValue);
    // wait for 30 milliseconds to see the dimming effect
    delay(30);
  }

    // fade in from min to max in increments of 5 points:
  for (int fadeValue = 0; fadeValue <= 255; fadeValue += 5) {
    // sets the value (range from 0 to 255):
    analogWrite(GREEN, fadeValue);
    // wait for 30 milliseconds to see the dimming effect
    delay(30);
  }

    // fade in from min to max in increments of 5 points:
  for (int fadeValue = 0; fadeValue <= 255; fadeValue += 5) {
    // sets the value (range from 0 to 255):
    analogWrite(BLUE, fadeValue);
    // wait for 30 milliseconds to see the dimming effect
    delay(30);
  }

}
