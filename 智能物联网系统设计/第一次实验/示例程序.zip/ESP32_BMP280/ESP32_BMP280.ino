#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_BMP280.h>
 
#define BMP_SDA 21                       //IC引脚定义
#define BMP_SCL 22                       //IC引脚定义
Adafruit_BMP280 bmp280;
 
void setup() {
  Serial.begin(115200);                  //串口初始化
  Serial.println("Initializing BMP280"); //串口打印字符
  boolean status = bmp280.begin(0x76);   //器件的IC地址是0X76或0X77
  if (!status) {
    Serial.println("Not connected");
}
}
void loop() {
  float temp = bmp280.readTemperature(); //定义变量读取温度值
  float press = bmp280.readPressure() / 100; //定义变量读取大气压值
  float Altitude= bmp280.readAltitude(); //定义变量读取海拔值
  
  Serial.print("Temperature:  ");    
  Serial.print(temp);                  //打印温度值
  Serial.println(" *C");  
  Serial.print("Pressure:  ");
  Serial.print(press);                 //打印大气压值
  Serial.println(" hP");  
  Serial.print("Altitude:  ");
  Serial.print(Altitude);              //打印海拔高度值
  Serial.println(" m");
  Serial.println("-------------------");
  delay(2000);                           //每两秒刷新一次
}